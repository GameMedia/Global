eMosbat TinyMCE Integration MOD for phpBB
=============

This is a phpBB3 MOD that change phpBB's simple editor to a full WYSIWYG Editor using TinyMCE.

Supported Features
-------

* support of smilies
* support of custom BBCodes
* support of attachments

Installation
-----------

    Upload MOD file in automod and click install.


Usage
-----

    You can change MOD's settings from .MOD tab in ACP.


