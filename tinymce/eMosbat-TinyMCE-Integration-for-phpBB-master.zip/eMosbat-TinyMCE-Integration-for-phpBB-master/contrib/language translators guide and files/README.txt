Language translator guide:

if you would like to translate this mod, please translate english texts in install_mod.xml and files in root folder.

change YOUR_LANGUAGE_NAME to your language name example: English
change YOU_USERNAME to your username
change YOUR_TRANSLATE_FOLDER to language folder name example: my_language_folder
change YOUR_LANGUAGE_NAME to your language id example: en

change language/YOUR_LANGUAGE_NAME folder name to your language id example: language/en
